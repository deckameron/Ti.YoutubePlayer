//
//  TiYoutubeplayer.h
//  Ti.YoutubePlayer
//
//  Created by Your Name
//  Copyright (c) 2026 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiYoutubeplayer.
FOUNDATION_EXPORT double TiYoutubeplayerVersionNumber;

//! Project version string for TiYoutubeplayer.
FOUNDATION_EXPORT const unsigned char TiYoutubeplayerVersionString[];

#import <TiYoutubeplayer/TiYoutubeplayerModuleAssets.h>
